public class Ensyu10 {
  public static void main(String[] args) {
    // 半径を管理する変数 rad  3を代入
    int rad = 3;
    // 結果の表示
    // 半径の表示
    System.out.println("radius = " + rad);
    // 円周の長さを表示
    System.out.println("circumference =" + Circle.circfer(rad));
    // 円の面積を表示
    System.out.println("area = " + Circle.area(rad));
  }
}

class Circle {
  // 円周率を格納するconstantクラス変数PIを宣言　3.1415を格納
  static final double PI = 3.1415;

  // circferメソッド(static)
  // 引数　半径rad:int 　戻り値　円周:double
  static double circfer(int rad) {
    // 半径から計算した円周を返却する
    // 円周=円周率×円の直径
    return Circle.PI * rad * 2;
  }

  // areaメソッド(static)
  // 引数　半径rad:int  戻り値　円の面積:double
  static double area(int rad) {
    // 円の面積を計算して返却する
    // 円の面積=円周率×半径の2乗
    return Circle.PI * Math.pow(rad, 2);
  }
  
}