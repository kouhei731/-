// 演習15で最低限なレベルに追記
// 追記した部分にのみコメント


import java.util.Scanner;
import java.util.Random; //Randomクラスをインポート

public class Ensyu15ad {
  public static void main(String[] args) {
    Scanner scn = new Scanner(System.in);
    Random random = new Random(); // ランダムクラスをインスタンス化

    final String BRANK = "-";
    final String PLAYER_NAME1 = "A";
    final String PLAYER_NAME2 = "C"; // CPUなので名前をCに変更

    String[][] fields = {{BRANK,BRANK,BRANK},{BRANK,BRANK,BRANK},{BRANK,BRANK,BRANK}};
    boolean turn = true;
    int inputX = 0;
    int inputY = 0;

    for(int i = 0; i < 9; i++){
      System.out.println("★ 現在の表★");
      System.out.println("  0 1 2");
      System.out.println("  -----");
      for(int j = 0; j < 3; j++){
        System.out.print(j+"|");
        for(int k = 0; k < 3; k++){
          System.out.print(fields[j][k]+" ");
        }
        System.out.println();
      }
      

      // 生成した乱数がすでに埋まっているマスだった場合はまずいので、無限ループの中で入力チェックを行う
      // 指定されたマスが埋まっていない場合にのみ無限ループから抜け出す
      while (true) {
        System.out.print( turn ? "先攻：" + PLAYER_NAME1 : "後攻：" + PLAYER_NAME2 );
        System.out.print("さんの横(x)座標を入力：");
        inputX = turn ? scn.nextInt() : random.nextInt(3); // プレイヤーターンの場合には入力値を、CPUターンの場合には乱数を代入する
        // CPUのターンの場合、生成された乱数を表示する
        if (!turn) {
          System.out.println(inputX);
        }

        System.out.print( turn ? "先攻：" + PLAYER_NAME1 + "さんの縦(y)座標を入力：" : "後攻：" + PLAYER_NAME2  + "さんの縦(y)座標を入力：");
        inputY = turn ? scn.nextInt() : random.nextInt(3); // プレイヤーターンの場合には入力値を、CPUターンの場合には乱数を代入する
        // CPUのターンの場合、生成された乱数を表示する
        if (!turn) {
          System.out.println(inputY);
        }

        // 入力チェック
        // 指定されたマスが空いているかどうか判定
        if(fields[inputY][inputX] == BRANK){
          // 空いている場合は問題ないのでループから抜け出す
          break;
        }else{
          // 埋まっている場合は再度入力し直し、乱数の生成のやり直しを行う
          // プレイヤーターンか、CPUターンかで表示する文言を帰る
          if(turn){
            // プレイヤーターンの場合
            System.out.println("まだ埋まっていない座標を入力して下さい。");
          }else{
            // CPUターンの場合
            System.out.println("CPUは焦って埋まっている座標をしてしまった。\n唸りながら考え直している。");
          }
        }
      }
      
      fields[inputY][inputX] = turn ? PLAYER_NAME1 : PLAYER_NAME2;

      if((fields[0][0] == PLAYER_NAME1 && fields[0][1] == PLAYER_NAME1 && fields[0][2] == PLAYER_NAME1)
      || (fields[1][0] == PLAYER_NAME1 && fields[1][1] == PLAYER_NAME1 && fields[1][2] == PLAYER_NAME1)
      || (fields[2][0] == PLAYER_NAME1 && fields[2][1] == PLAYER_NAME1 && fields[2][2] == PLAYER_NAME1)
      || (fields[0][0] == PLAYER_NAME1 && fields[1][0] == PLAYER_NAME1 && fields[2][0] == PLAYER_NAME1)
      || (fields[0][1] == PLAYER_NAME1 && fields[1][1] == PLAYER_NAME1 && fields[2][1] == PLAYER_NAME1)
      || (fields[0][2] == PLAYER_NAME1 && fields[1][2] == PLAYER_NAME1 && fields[2][2] == PLAYER_NAME1)
      || (fields[0][0] == PLAYER_NAME1 && fields[1][1] == PLAYER_NAME1 && fields[2][2] == PLAYER_NAME1)
      || (fields[0][2] == PLAYER_NAME1 && fields[1][1] == PLAYER_NAME1 && fields[2][0] == PLAYER_NAME1)){
        System.out.println("★★ 勝利★★");
        System.out.println("  0 1 2");
        System.out.println("  -----");
        for(int j = 0; j < 3; j++){
          System.out.print(j+"|");
          for(int k = 0; k < 3; k++){
            System.out.print(fields[j][k]+" ");
          }
          System.out.println();
        }
        break;
      }else if((fields[0][0] == PLAYER_NAME2 && fields[0][1] == PLAYER_NAME2 && fields[0][2] == PLAYER_NAME2)
            || (fields[1][0] == PLAYER_NAME2 && fields[1][1] == PLAYER_NAME2 && fields[1][2] == PLAYER_NAME2)
            || (fields[2][0] == PLAYER_NAME2 && fields[2][1] == PLAYER_NAME2 && fields[2][2] == PLAYER_NAME2)
            || (fields[0][0] == PLAYER_NAME2 && fields[1][0] == PLAYER_NAME2 && fields[2][0] == PLAYER_NAME2)
            || (fields[0][1] == PLAYER_NAME2 && fields[1][1] == PLAYER_NAME2 && fields[2][1] == PLAYER_NAME2)
            || (fields[0][2] == PLAYER_NAME2 && fields[1][2] == PLAYER_NAME2 && fields[2][2] == PLAYER_NAME2)
            || (fields[0][0] == PLAYER_NAME2 && fields[1][1] == PLAYER_NAME2 && fields[2][2] == PLAYER_NAME2)
            || (fields[0][2] == PLAYER_NAME2 && fields[1][1] == PLAYER_NAME2 && fields[2][0] == PLAYER_NAME2)) {
        System.out.println("★★ 敗北★★");
        System.out.println("  0 1 2");
        System.out.println("  -----");
        for(int j = 0; j < 3; j++){
          System.out.print(j+"|");
          for(int k = 0; k < 3; k++){
            System.out.print(fields[j][k]+" ");
          }
          System.out.println();
        }
        break;
      }else if(i == 8){
        System.out.println("★★ 引き分け★★");
        System.out.println("  0 1 2");
        System.out.println("  -----");
        for(int j = 0; j < 3; j++){
          System.out.print(j+"|");
          for(int k = 0; k < 3; k++){
            System.out.print(fields[j][k]+" ");
          }
          System.out.println();
        }
        break;
      }
      turn = !turn;
    }

    scn.close();
  }
}
