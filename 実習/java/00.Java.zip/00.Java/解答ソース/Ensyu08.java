public class Ensyu08 {
  public static void main(String[] args) {
    // Functionsクラスをインスタンス化 変数funcsに格納する
    Functions funcs = new Functions();
    // 数値を扱う変数num1 100を代入する
    int num1 = 100;
    // 数値を扱う変数num2 200を代入する
    int num2 = 200;
    // sumメソッドを呼び出し、結果を表示
    System.out.println("Sum from "+ num1 +" to "+ num2 +" = " + funcs.sum(num1, num2));
    // averageメソッドを呼び出し、結果を表示
    System.out.println("Average " + num1 + " and " + num2 + " = " + funcs.average(num1, num2));
  }
}

// Functionsクラス
// sumメソッドとaverageメソッドを持つ
class Functions {
  // sumメソッド
  //引数x:int,y:int  戻り値 合計値:int
  //xからyまでの合計値を返却する。
  public int sum(int x,int y) {
    // 合計値を管理する変数 total
    int total = 0;
    // xからyまで繰り返す
    for(int i = x; i <= y; i++){
      // 数を一つずつ足し込む
      total += i;
    }
    // totalを返却する
    return total;
  }

  // sumメソッド
  //引数x:int,y:int  戻り値 平均値:int
  //xとyの平均値を返却する。
  public int average(int x,int y) {
    // xとyを足し、2で割った値を返却する
    return (x + y)/2;
  }
  
}