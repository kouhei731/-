public class Ensyu11 {
  public static void main(String[] args) {
    // 整数値を格納する変数x 11で初期化
    int x = 11;
    // 整数値を格納する変数y 18で初期化
    int y = 18;
    // 整数値を格納する変数z 7で初期化
    int z = 7;
    // SumAveクラスをインスタンス化　変数saに格納
    SumAve sa = new SumAve();

    // 結果の表示
    // calcメソッド(引数2つ)の呼び出し
    // 2つの数の合計値を表示
    System.out.println("Sum = " + sa.calc(x,y));
    // calcメソッド(引数3つ)の呼び出し
    // 3つの数の平均値を表示
    System.out.println("Ave = " + sa.calc(x,y,z));
  }
}

// SumAveクラス
// calcメソッド(引数2つ)とcalcメソッド(引数3つ)を持つ
class SumAve {
  // calcメソッド(引数2つ)
  // 引数　num1:int,num2:int  戻り値 合計値:int
  public int calc(int num1,int num2){
    // 引数2つの合計値を返却する
    return num1 + num2;
  }

  // calcメソッド(引数3つ)
  // 引数　num1:int,num2:int,num3:int  戻り値 平均値:int
  public int calc(int num1,int num2,int num3){
    // 引数3つの平均値を返却する
    return (num1+num2+num3)/3;
  }
}