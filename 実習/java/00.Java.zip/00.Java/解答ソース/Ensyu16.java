import java.util.Scanner; //スキャナークラスをインポート

// メインのクラス
public class Ensyu16 {
  // このメインメソッドでは、Gameクラスのインスタンス化とメソッド呼び出ししか行わない
  public static void main(String[] args) {
    // Gameクラスのインスタンス化
    Game game = new Game();
    // ○×ゲームを開始するstartメソッドの呼び出し
    game.start();
  }
}

// ○×ゲームに関する変数やメソッドをまとめたGameクラス
class Game {
  //スキャナークラスをインスタンス化
  Scanner scn = new Scanner(System.in);

  //ゲームで使用する文字列をインスタンス変数のconstant変数として宣言、初期化しておく
  // 空欄を表す文字列 -
  final String BRANK = "-";
  // プレイヤー１のお名前 A
  final String PLAYER_NAME1 = "A";
  // プレイヤー２のお名前 B
  final String PLAYER_NAME2 = "B";

  // ○×ゲームのフィールドを表す2重配列(3×3)
  // BRANKで初期化しておく
  String[][] fields = {{BRANK,BRANK,BRANK},{BRANK,BRANK,BRANK},{BRANK,BRANK,BRANK}};

  // 先攻のターンなのか、後攻のターンなのかを管理する変数 turn
  // true → 先攻、false → 後攻
  boolean turn = true;

  // startメソッド
  // 引数：無し　戻り値：なし
  // ○×ゲームを開始から終了までコントロールするメソッド
  void start(){
    // 無限ループ　1ループ=1ターン
    // 必ずゲームが終了する(breakする)ようになっているので、無限ループでも問題なし
    // 現場では危険性の高い無限ループはほぼ使われない。
    // ○×ゲームの場合は9ターンまでしかないのは明白なので、for文で9回ループ　推奨
    while(true){
      // 現状の表示
      System.out.println("★ 現在の表★");
      display();

      // 入力メソッドを呼び出す
      input();

      // ゲームが終了しているか確認するisEndメソッドを呼び出し、返却値で判定
      if(isEnd()){
        // trueが返却された場合はゲーム終了、最後の盤面を表示し無限ループから抜け出す
        display();
        break;
      }else{
        // falseが返却された場合はゲーム続行、手番を入れ替えてループのはじめに戻る
        turn = !turn;
      }
    }
  }

  // inputメソッド
  // 引数：無し　戻り値：なし
  // 座標の入力を行うメソッド
  void input(){
    // 入力値を管理する変数inputX,inputY
    int inputX = 0;
    int inputY = 0;
    // 不正な値を検出した時に表示するメッセージの文字列 msg
    String msg = "";

    // 正しい値が入力されるまで繰り返す
    while (true) {
      // 入力を促す文字列を出力(横軸)
      // 先攻なら先攻プレイヤー名を、後攻なら後攻プレイヤー名を表示する
      System.out.print( turn ? "先攻：" + PLAYER_NAME1 : "後攻：" + PLAYER_NAME2 );
      System.out.print("さんの横(x)座標を入力：");
      // 入力(横軸)
      inputX = scn.nextInt();

      // 入力を促す文字列を出力(縦軸)
      // 先攻なら先攻プレイヤー名を、後攻なら後攻プレイヤー名を表示する
      System.out.print( turn ? "先攻：" + PLAYER_NAME1 : "後攻：" + PLAYER_NAME2 );
      System.out.print("さんの縦(y)座標を入力：");
      // 入力(縦軸)
      inputY = scn.nextInt();

      // 入力された値が正しいかチェックするcheckInputメソッドを呼び出す
      // 戻り値は表示するべき文字列:String 正しい値が入力されていた場合は空文字
      msg = checkInput(inputY, inputX);

      // msgの中身が空文字の場合は正しい値なのでループから抜け出す
      if(msg.length() == 0){
        break;
      }else{
        // 空文字でない場合はメッセージを表示してループの始めに戻る Line.73
        System.out.println(msg);
      }
    }
    
    // 無限ループを抜け出してきた、すなわち正しい値が入力されているのでターンプレイヤーの名前を指定された座標に入力
    fields[inputY][inputX] = turn ? PLAYER_NAME1 : PLAYER_NAME2;
  }

  // inputメソッド
  // 引数： int y(y軸座標),int x(x軸座標) 　戻り値：msg:String(表示するメッセージ)
  // 引数で送られてきた座標が正しい値かどうかチェックするメソッド
  // 重複や存在しない座標が入力された場合は入力し直すように呼びかける文字列を返却する
  String checkInput(int y,int x){
    // 返却用文字列 空文字として初期化
    // 重複や存在しない座標が入力された場合は入力し直すように呼びかける文字列セットする
    String msg = "";
    
    // 座標が0~2の範囲内かどうか判定
    if(0 <= y && y <= 2 && 0 <= x && x <= 2){
      // 座標が0~2の場合、空欄かどうかチェックする
      if(!isBrank(fields[y][x])){
        // 座標が空欄でなかった場合、msgに”まだ埋まっていない座標を入力して下さい。”をセットする
        msg = "まだ埋まっていない座標を入力して下さい。";
      }
      // 座標が0~2で空欄の場合は正しい値なので、空文字のままにする
    }else{
      // 座標が0~2の範囲内でない場合、msgに"座標は0~2までの整数で入力してください。"をセットする
      msg = "座標は0~2までの整数で入力してください。";
    }
    // msgを返却する
    return msg;
  }

  // isEndメソッド
  // 引数： なし　戻り値：flg:boolean
  // ゲームの終了条件を満たしているかチェックし、終了する場合には終了処理をするメソッド
  // ゲームの終了条件(いずれかのプレイヤーが1列そろえているor全てマスが埋まっている)を満たしていればtrueを、満たしていなければfalseを返却する
  boolean isEnd(){
    // 返却用の変数 flg falseで初期化しておく
    boolean flg = false;
    // 先攻のプレイヤーが勝っているかどうかの判定
    // フィールド上の縦横斜めのいずれかがそろっていれば勝利
    if(isVictory(PLAYER_NAME1)){
      // 先攻プレイヤーが勝利している場合
      // 勝利メッセージを表示
      System.out.println("★★ "+ PLAYER_NAME1 +"さんの勝利★★");
      // 返却用のflgにtrueを代入する
      flg = true;

    // 後攻のプレイヤーが勝っているかどうかの判定
    // フィールド上の縦横斜めのいずれかがそろっていれば勝利
    }else if(isVictory(PLAYER_NAME2)){
      // 後攻プレイヤーが勝利している場合
      // 勝利メッセージを表示
      System.out.println("★★ "+ PLAYER_NAME2 +"さんの勝利★★");
      // 返却用のflgにtrueを代入する
      flg = true;

    // 盤面がすべて埋まっているかどうかの判定をするisFillメソッドを呼び出し判定
    }else if(isFull()){
      // どちらのプレイヤーも勝利しておらず、
      // 全てのマスが埋まっている場合は引き分け
      // 引き分けメッセージを表示
      System.out.println("★★ 引き分け★★");
      // 返却用のflgにtrueを代入する
      flg = true;
    }

    // flgを返却する。いずれかの終了条件を満たしていればtrue、そうでなければfalse。
    return flg;
  }
  
  // displayメソッド
  // 引数： なし　戻り値：なし
  // 呼び出された時点での盤面を表示をするメソッド
  void display(){
    // フィールドの座標案内(横軸)
    System.out.println("  0 1 2");
    System.out.println("  -----");
    // 2重ループを使って、配列を平面上に描画する
    // 外のループは行(縦軸)のループ　1周 = 1行
    for(int j = 0; j < 3; j++){
      // フィールドの座標案内(縦軸)
      System.out.print(j+"|");
      // 内のループは列(横軸)のループ　1周 = 1マス
      for(int k = 0; k < 3; k++){
        // フィールドの状態を1マスずつ描画(改行なし)
        System.out.print(fields[j][k]+" ");
      }
      // 改行
      System.out.println();
    }
  }

  // isBrankメソッド
  // 引数：　String:str　戻り値：:boolean
  // 引数の文字列がBRANKと等しいかチェック
  boolean isBrank(String str){
    // 引数strがBRANKと等しければtrue、等しくなければfalseを返却する
    return str == BRANK;
  }

  // isFullメソッド
  // 引数：　なし　戻り値：flg:boolean
  // 盤面が全て埋まっているかどうかチェック
  // 全て埋まっていればtrueを、埋まっていなければfalseを返却
  boolean isFull(){
    // 返却用変数flg trueで初期化
    boolean flg = true;
    // fieldsを2重ループで走査
    for (int i = 0;i < 3; i++){
      for (int j = 0;j < 3; j++){
        // 全てのマスを確認し、BRANKのマスがあればflgにflaseを代入する
        if(isBrank(fields[i][j])){
          flg = false;
        }
      }
    }
    // flgを返却する
    return flg;
  }

  // isVictoryメソッド
  // 引数：　String:playerName　戻り値： boolean:flg
  // 引数で送られてきたプレイヤーが勝利条件を満たしているかチェック
  // 勝利条件を満たしていた場合はtrueを、満たしていなければfalseを返却する
  boolean isVictory(String playerName){
    // 返却用変数flg flaseで初期化
    boolean flg = false;
    // 勝利条件を満たしているかどうか判定する
    // 縦、横、斜めのうち1列でもそろっていれば勝利
    if(  (fields[0][0] == playerName && fields[0][1] == playerName && fields[0][2] == playerName) // 縦1列目
      || (fields[1][0] == playerName && fields[1][1] == playerName && fields[1][2] == playerName) // 縦2列目
      || (fields[2][0] == playerName && fields[2][1] == playerName && fields[2][2] == playerName) // 縦3列目
      || (fields[0][0] == playerName && fields[1][0] == playerName && fields[2][0] == playerName) // 横1列目
      || (fields[0][1] == playerName && fields[1][1] == playerName && fields[2][1] == playerName) // 横2列目
      || (fields[0][2] == playerName && fields[1][2] == playerName && fields[2][2] == playerName) // 横3列目
      || (fields[0][0] == playerName && fields[1][1] == playerName && fields[2][2] == playerName) // 斜め1列目
      || (fields[0][2] == playerName && fields[1][1] == playerName && fields[2][0] == playerName)) { // 斜め2列目
      // 勝利条件を満たしている場合、trueを代入する
      flg = true;
    }
    // flgを返却する
    return flg;
  }
}
