public class Ensyu09 {
  public static void main(String[] args) {
    // 半径を管理する変数 rad  3を代入
    int rad = 3;
    // Corcleクラスをインスタンス化 変数cirに格納
    Circle cir = new Circle();
    // 結果の表示
    // 半径の表示
    System.out.println("radius = " + rad);
    // 円周の長さを表示
    System.out.println("circumference =" + cir.circfer(rad));
    // 円の面積を表示
    System.out.println("area = " + cir.area(rad));
  }
}

// Circleクラス
// 円周を求めるcircferメソッドと円の面積を求めるareaメソッドを持つ
class Circle{
  // 円周率を格納するconstant変数PIを宣言　3.1415を格納
  final double PI = 3.1415;

  // circferメソッド
  // 引数　半径rad:int 　戻り値　円周:double
  public double circfer(int rad) {
    // 半径から計算した円周を返却する
    // 円周=円周率×円の直径
    return PI * rad * 2;
  }

  // areaメソッド
  // 引数　半径rad:int  戻り値　円の面積:double
  public double area(int rad) {
    // 円の面積を計算して返却する
    // 円の面積=円周率×半径の2乗
    return PI * Math.pow(rad, 2);
  }
}