public class Ensyu12 {
  public static void main(String[] args) {
    // 整数値を管理する変数x 5で初期化
    int x = 5;
    // Clacクラスをインスタンス化 変数cに格納
    // 引数１つのコンストラクタを呼び出し
    Clac c = new Clac(x);

    // 結果を表示
    // 総和を表示
    System.out.println("sum = " + c.sum());
    // 階乗を表示
    System.out.println("factorial = " + c.fact());
  }
}

// Clacクラス
// sumメソッド,factメソッドを持つ
class Clac {
  // 整数値を管理するインスタンス変数x
  int x;

  // コンストラクタ(引数1つ:int)
  Clac(int x){
    // 引数の整数をxに格納
    this.x = x;
  }

// sumメソッド
// 引数無し　戻り値　総和:int
// 1からxまでの総和を求める
  public int sum() {
    // 総和を管理する変数total 0で初期化
    int total = 0;
    // 1からxまで繰り返す
    for(int i = 1; i <= this.x; i++){
      // totalに足し込んでいく
      total += i;
    }
    // totalを返却
    return total;
  }

// factメソッド
// 引数無し　戻り値　階乗:int
// 1からxまでの階乗を求める
  public int fact() {
    // 階乗値を管理する変数fact 1で初期化
    int fact = 1;
    // 1からxまで繰り返す
    for(int i = 1;i <= this.x; i++){
      // factにかけ続けていく
      fact *= i;
    }
    // factを返却する
    return fact;
  }
}