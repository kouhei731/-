# 機械学習ライブラリ

import numpy as np
import random

# 重みを生成する関数 create_weights の定義
'''
関数名：create_weights
引数：
  input_layer_number = 入力層のユニット数
  output_layer_number = 出力層のユニット数
処理：
  行の数 = 出力層のユニット数、列の数 = 入力層のユニット数の行列を生成する
  ただし行列の要素には０以上１以下の実数を配置する
戻り値
  生成した重みの行列
'''
def create_weights(input_layer_number, output_layer_number):
  # 出力層のユニット数　ｘ　入力層のユニット数 の０行列（要素がすべて０の行列）を生成する
  out_matrix = np.zeros((output_layer_number, input_layer_number))
  # 行列の要素に０以上１位かの実数を設定する（２重ループ）
  for i in range(output_layer_number):
    for j in range(input_layer_number):
      out_matrix[i][j] = random.uniform(0, 1)
  # 行列を返す
  return out_matrix

# 加重和（内積）を求める関数 w_sum の定義
def w_sum(a, b):
    # ２つの引数のリストの長さが等しいとき以下を実行する
    assert(len(a) == len(b))
    # 加重和の初期化
    output = 0
    # 加重和を求める
    # 引数のリストの長さ分繰り返す
    for i in range(len(a)):
        # リストの要素同士を掛けて合計を求める
        output += (a[i] * b[i])
    # 加重和を返す
    return output

# ベクトルと行列のかけ算を求める関数 vect_mat_mul の定義
def vect_mat_mul(vect, matrix):
    # 加重和リストの初期化
    output = []
    # ベクトルの長さ（＝行列の行リストの長さ）分繰り返す
    for i in range(len(matrix)):
        # ベクトルの行列の各行との加重和を求める
        output.append(w_sum(vect, matrix[i]))
    # 加重和のリストを返す
    return output

# ２つのリストの要素間を総なめして要素ごとのかけ算をして
# その結果を行列に格納する関数 outer_prod の定義
def outer_prod(a, b):
    # a 行 b 列のゼロ行列を生成する
    out = np.zeros((len(a), len(b)))
    # a 行 b 列の行列にリスト a とリスト b の
    # 要素を総なめしたかけ算を行い、行列に格納する
    for i in range(len(a)):
        for j in range(len(b)):
            out[i][j] = a[i] * b[j]
    # 要素間のかけ算の結果を保存した行列を返す
    return out

# 予測値を求める関数 nuural_network の定義
def neural_network(input, weights):
    # ベクトルと行列の加重和を求める
    pred = vect_mat_mul(input, weights)
    # 予測値のリストを返す
    return pred

# 学習関数 grad_descent_learn(input, truth, pred, weights, alpha) の定義
'''
関数名：grad_descent_learn
引数：
    input：入力値リスト
    truth：目的値リスト
    pred：予測値リスト
    weights：重みリスト
    alpha：重み再微調整値
処理：勾配降下法に基づき重みを修正する
戻り値：修正された重みリスト
'''
def grad_descent_learn(input, truth, pred, weights, alpha):
    # デルタの初期化
    delta = []
    # 予測値の数分繰り返す
    for i in range(len(truth)):
        # デルタを求める
        delta.append(pred[i] - truth[i])
    # 重みの微調整量を求め行列に格納する
    weight_deltas = outer_prod(delta, input)
    # 重み行列を更新する
    for i in range(len(weights)):
        for j in range(len(weights[0])):
            weights[i][j] -= alpha * weight_deltas[i][j]
    # 重み行列を返す
    return weights
