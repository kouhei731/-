import my_ml as ml

# 手書き文字データの初期化
# 数字１ パターン１
number_1_str = [
  "    11    ",
  "    11    ",
  "   111    ",
  "   111    ",
  "    11    ",
  "    11    ",
  "    11    ",
  "    11    ",
  "    11    ",
  "    11    "
]
# 数字１ パターン２
number_1_str_2 = [
  "    11    ",
  "    11    ",
  "   111    ",
  "   111    ",
  "    11    ",
  "   11     ",
  "  11      ",
  "  11      ",
  "  11      ",
  "  11      "
]
# 数字１ パターン３
number_1_str_3 = [
  "    11    ",
  "    11    ",
  "   111    ",
  "   111    ",
  "    11    ",
  "          ",
  "    11    ",
  "    11    ",
  "    11    ",
  "    11    "
]
# 数字１ 認識できるか？
number_1_str_4 = [
  "    11    ",
  "   111    ",
  "    11    ",
  "    11    ",
  "    11    ",
  "   11     ",
  "  11      ",
  "  11      ",
  "  11      ",
  "  11      "
]

new_number_str = [
  "    11    ",
  "   111    ",
  "    11    ",
  "    11    ",
  "    11    ",
  "    11    ",
  "    11    ",
  "    11    ",
  "   11     ",
  "   11     "
]

# 文字列配列を数値配列に変換する関数 str_to_number_list の定義
'''
関数名：str_to_number_list
引数：str = 手書き文字列（文字列のリスト）
処理：手書き文字列（文字列リスト）を数値リストに変換
戻り値：数値２次元配列
'''
def str_to_number_list(str):
  # 数値リストの初期化
  number_pattern = []
  # 文字列リストを数値リストに変換（２重ループ）
  # 文字 '1' なら数値の 1 に、空白文字 ' ' なら数値の 0 に変換
  # 行数分繰り返す
  for i in range(len(str)):
    # 列数分（文字数分）繰り返す
    for j in range(len(str[i])):
      # 文字が '1' なら
      if str[i][j] == '1':
        # 数値リストに 1 を追加する
        number_pattern.append(1)
      # そうでなければ
      else:
        # 数値リストに 0 を追加する
        number_pattern.append(0)
  # 数値リストを返す
  return number_pattern

# 認識した数値を返す関数 number_recognition 関数の定義
'''
関数名：number_recognition
引数：pred = 予測値リスト
処理：
  予測値リストの最大値が存在する要素番号を返す
戻り値：最大値の要素番号＝認識した数字
'''
def number_recognition(pred):
  max = pred[0]
  recog_number = 0
  for i in range(len(pred)):
    if (max < pred[i]):
      max = pred[i]
      recog_number = i
  return recog_number


# 数字１ パターン１の設定
input_1 = str_to_number_list(number_1_str)
# 数字１ パターン２の設定
input_2 = str_to_number_list(number_1_str_2)
# 数字１ パターン３の設定
input_3 = str_to_number_list(number_1_str_3)
# 数字１ パターン４の設定
input_4 = str_to_number_list(number_1_str_4)

# 学習用入力データの設定
input = [input_1, input_2, input_3, input_4]

# 目的値（正解）の設定（数字の１を学習させる）
truth = [0, 1, 0, 0, 0, 0, 0, 0, 0, 0]

# 重みを生成
weights = ml.create_weights(len(input[0]), len(truth))

# アルファの初期化
alpha = 0.001

# １数字１のパターン１からパターン４までを３００回学習
# 数字１のパターン１からパターン４までを学習
for i in range(len(input)):
  print('数字１の学習：パターン {}'.format(i + 1))
  # 各数字を５００回学習
  for iter in range(300):
    # 数字 i の予測値リストを求める
    pred = ml.neural_network(input[i], weights)
    # 学習する（重みを調整して更新する）
    weights = ml.grad_descent_learn(input[i], truth, pred, weights, alpha)
  print('数字１：パターン {} の学習終了'.format(i + 1))

# 数字１　新たなパターンの予測
print('新たなパターンの数字１の認識')
new_input = str_to_number_list(new_number_str)
pred = ml.neural_network(new_input, weights)
# 認識した数字を求める
recog_number = number_recognition(pred)
# 認識結果を表示する
print('認識 = ', recog_number)